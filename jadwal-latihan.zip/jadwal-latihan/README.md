# Timer

Aplikasi jadwal latihan (timer, riwayat, PiP) — satu file HTML, jalan offline, bisa di-install ke layar utama (PWA).

## Deploy ke GitHub Pages
1. Buat repo baru di GitHub, lalu upload semua isi folder ini (termasuk folder `.github`).
2. Buka **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push ke branch `main` — tunggu tab **Actions** selesai.
4. Aplikasi live di `https://USERNAME.github.io/NAMA-REPO/`.

## Install di HP
Buka link di browser → **Add to Home Screen** (iOS: Share → Add to Home Screen).

## Update
Edit `index.html`, lalu ubah `VERSION` di `sw.js` (mis. `workout-v2`) supaya cache ter-refresh.
